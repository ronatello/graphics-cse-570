#!/usr/bin/env bash

python util/mesh_viewer.py \
--files \
exp3_meshes/T347_0.obj \
exp3_meshes/T347_3.obj \
exp3_meshes/T347_4.obj
