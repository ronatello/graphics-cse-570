#!/usr/bin/env bash

python util/mesh_viewer.py \
--files checkpoints/cubes/meshes/horseshoe_4_0.obj \
checkpoints/cubes/meshes/horseshoe_4_2.obj \
checkpoints/cubes/meshes/horseshoe_4_3.obj \
checkpoints/cubes/meshes/horseshoe_4_4.obj